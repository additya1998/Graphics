#include "main.h"

const color_t COLOR_YELLOW = { 255, 255, 0 };
const color_t COLOR_LBLUE = { 153, 255, 255 };
const color_t COLOR_PURPLE = { 153, 0, 153 };
const color_t COLOR_WHITE = { 255, 255, 255 };
const color_t COLOR_BLUE = { 0, 128, 255 };
const color_t COLOR_BROWN = { 101, 67, 33 };
const color_t COLOR_RED = { 236, 100, 75 };
const color_t COLOR_GREEN = { 0, 255, 0 };
const color_t COLOR_GREY = { 220, 220, 220 };
const color_t COLOR_BLACK = { 52, 73, 94 };
const color_t COLOR_SKIN = { 255, 224, 189 };
const color_t COLOR_SAND = { 76, 70, 50 };
const color_t COLOR_BACKGROUND = { 255, 255, 255 };
